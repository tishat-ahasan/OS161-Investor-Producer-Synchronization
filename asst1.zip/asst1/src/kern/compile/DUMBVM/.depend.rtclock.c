rtclock.o: ../../dev/generic/rtclock.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/kern/errno.h \
 ../../include/lib.h ../../include/cdefs.h opt-noasserts.h \
 ../../include/clock.h ../../include/kern/time.h \
 ../../dev/generic/rtclock.h autoconf.h
