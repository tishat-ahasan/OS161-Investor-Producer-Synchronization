/* Automatically generated; do not edit */
#ifndef _OPT_HANGMAN_H_
#define _OPT_HANGMAN_H_
#define OPT_HANGMAN 0
#endif /* _OPT_HANGMAN_H_ */
